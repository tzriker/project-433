const BASE_URL = "http://localhost:3001/employees"

export default BASE_URL